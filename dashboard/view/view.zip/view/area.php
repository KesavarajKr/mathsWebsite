<?php 
	require_once('navbar.php');
	require_once('../modal/db.php');
?>
<main class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Area Details</div>
					
					<div class="ms-auto">
						<a  class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleVerticallycenteredModal">Add Area</a>
					</div>
				</div>
				<!--end breadcrumb-->
				
				<!-- <hr/> -->
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Area Name</th>
										<th>Delete</th>
									</tr>
								</thead>
								
								<tbody>
									<?php 
									$i=0;
                                            $sql = "SELECT * FROM area";
                                            $query = mysqli_query($con,$sql);
  											while($row = mysqli_fetch_array($query))
                                            {               
                                            $cont=$row['area_id'];      
                                            	 $sql1 = "SELECT area_name FROM area where area_id='$cont'";
                                            $query1 = mysqli_query($con,$sql1);
  											$row1 = mysqli_fetch_array($query1);
                                                $Area_name=$row1['area_name'];
                                            	
                                       $i=$i+1;
                                                ?>
									<tr>
										<td><?php echo $i ?></td>
										<td><?php echo $Area_name?></td>
										
										<td><a href="../contoller/deleteArea.php?area_name=<?php echo $row["area_name"]; ?>" class="btn btn-danger"><i class="bi bi-trash-fill" style="margin-left:0px"></i></a></td>
									</tr>
									<?php

}
?>
								</tbody>
							
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Area Name</th>
										<th>Delete</th>
									</tr>
								</tfoot>
							</table>
						</div>
					</div>
				</div>
				
			</main>
<?php
	require_once('footer.php');
 ?>
 <div class="modal fade" id="exampleVerticallycenteredModal" tabindex="-1" aria-hidden="true">
											<div class="modal-dialog modal-dialog-centered">
												<div class="modal-content">
													<div class="modal-header">
														<h5 class="modal-title">Add Area</h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
													</div>
													<div class="modal-body">
										<form class="row g-3" method="POST" action="areaInsert.php">
                                  <div class="col-12">
                                    <label class="form-label">Area Name</label>
                                    <input type="text" name="AreaName" class="form-control" placeholder="City Name">
                                  </div>
                                  
                             
													</div>
													<div class="modal-footer">
														<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
														<button type="submit" class="btn btn-primary">Save changes</button>
													</div>
													 </form>
												</div>
											</div>
										</div>