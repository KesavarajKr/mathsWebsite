<?php
require_once('../modal/db.php');
$Area_Name=$_POST['AreaName'];

$sql = "INSERT INTO area (area_name)
VALUES ('$Area_Name')";	

if ($con->query($sql) === TRUE) {
  echo '<script>alert("Area details Inserted successfully")</script>';
  include 'area.php';
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}

$con->close();
?>

