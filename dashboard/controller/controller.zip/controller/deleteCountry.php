<?php 
	require_once('../modal/db.php');

	$name=$_GET['country_name'];


	$sql = "DELETE FROM country WHERE country_name='$name'";

if ($con->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $con->error;
}

$con->close();

	
?>
