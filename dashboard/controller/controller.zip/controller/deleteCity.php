<?php 
	require_once('../modal/db.php');

	$name=$_GET['city_name'];


	$sql = "DELETE FROM city WHERE city_name='$name'";

if ($con->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $con->error;
}

$con->close();

	
?>
